export class Constant {
  public static ApiRoot = "http://localhost:36946/";
  public static TokenService = "api/token";
  public static GreetingService = "api/Greeting";
}
