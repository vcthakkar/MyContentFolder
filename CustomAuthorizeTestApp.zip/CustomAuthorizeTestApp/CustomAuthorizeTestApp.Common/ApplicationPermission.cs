﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CustomAuthorizeTestApp.Common
{
    public class ApplicationPermission {


        public string Permission { get; set; }
        public bool IsValid { get; set; }
    }
}
