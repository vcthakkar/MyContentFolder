﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CustomAuthorizeTestApp.Common {
    public static class Permission {
        public const string Administrator = nameof(Administrator);
        public const string User = nameof(User);
    }
}
