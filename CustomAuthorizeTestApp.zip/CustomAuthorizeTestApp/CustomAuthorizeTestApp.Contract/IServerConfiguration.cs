﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CustomAuthorizeTestApp.Contract {
    public interface IServerConfiguration {

        string AdministratorPermissionName { get; }
        int UserCacheValidityTime { get; }
    }
}

