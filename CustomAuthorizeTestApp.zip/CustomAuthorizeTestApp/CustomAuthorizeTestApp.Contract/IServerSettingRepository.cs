﻿using CustomAuthorizeTestApp.Common;
using System;
using System.Collections.Generic;
using System.Security.Principal;
using System.Text;

namespace CustomAuthorizeTestApp.Contract {
    public interface IServerSettingRepository {

        IEnumerable<ServerSetting> GetServerSettings();

    }
}
