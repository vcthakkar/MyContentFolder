﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using CustomAuthorizeTestApp.Security;
using CustomAuthorizeTestApp.Common;

namespace CustomAuthorizeTestApp.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [RequiresPermission(Permission.Administrator)]
    public class ValuesController : Controller
    {
        
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

    }
}
