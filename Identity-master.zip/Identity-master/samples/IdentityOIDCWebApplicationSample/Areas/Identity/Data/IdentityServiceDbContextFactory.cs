using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.DependencyInjection;

namespace IdentityOIDCWebApplicationSample.Identity.Data
{
}
